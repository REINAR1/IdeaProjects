package com.company;

import java.util.Scanner;

public class Main {
    public static double plus(double firstnum, double secnum) {
        return firstnum + secnum;
    }


    public static double minus(double firstnum, double secnum) {
        return firstnum - secnum;
    }


    public static double div(double firstnum, double secnum) {
        return firstnum / secnum;
    }


    public static double mult(double firstnum, double secnum) {
        return firstnum * secnum;
    }


    public static double pow(double firstnum, double secnum) {
        return Math.pow(firstnum, secnum);
    }


    public static double sqrt(double firstnum) {
        return Math.sqrt(firstnum);
    }


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int finish = 0;
        System.out.println("Welcome to the worst calculator!!!");
        do {

            System.out.println("Choose your math action: 1=+ ,2=-, 3=/, 4=*, 5=↑, 6=√");
            int action = scanner.nextInt();
            double result = 0;
            System.out.println("Enter first num pls");
            double firstnum = scanner.nextDouble();
            System.out.println("Good choice! Now enter second num");
            double secnum = scanner.nextDouble();

            if (action == 1) {
                result = plus(firstnum, secnum);
            }
            if (action == 2) {
                result = minus(firstnum, secnum);
            }
            if (action == 3) {
                result = div(firstnum, secnum);
            }
            if (action == 4) {
                result = mult(firstnum, secnum);
            }
            if (action == 5) {
                result = pow(firstnum, secnum);
            }
            if (action == 6) {
                result = sqrt(firstnum);
            }
            System.out.println("Result: " + result);


            System.out.println("To exit type \"666\" or anything else to try again ");
            finish = scanner.nextInt();
        } while (finish != 666);
    }
}
